#Reference:
+ Poisson distribution: https://en.wikipedia.org/wiki/Poisson_distribution
+ CDF: https://en.wikipedia.org/wiki/Cumulative_distribution_function#Properties
+ Mean and variance: http://www.stat.yale.edu/Courses/1997-98/101/rvmnvar.htm
